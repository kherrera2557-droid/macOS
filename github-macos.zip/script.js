const windows=document.getElementById("windows"), template=document.getElementById("window-template");
let z=20, notes=[{title:"Welcome",body:"Welcome to GitHub macOS!\\n\\nThis is a browser-based desktop you can customize.\\n\\nTry the apps in the dock."}];

const apps={
finder:{title:"Finder",html:`<div class="finder"><aside class="sidebar"><p class="side-title">Favorites</p><button class="side-item active">🏠 Home</button><button class="side-item">📄 Documents</button><button class="side-item">⬇️ Downloads</button><button class="side-item">🖼️ Pictures</button></aside><div class="file-area"><h2>Home</h2><div class="file-grid"><button class="file">📁<span>Projects</span></button><button class="file">📁<span>Games</span></button><button class="file">📄<span>README.txt</span></button><button class="file">🖼️<span>Wallpaper</span></button></div></div></div>`},
browser:{title:"Browser",html:`<div class="browser"><div class="browser-bar"><button class="action" onclick="browserBack()">‹</button><button class="action" onclick="browserForward()">›</button><input id="urlbar" value="https://example.com"><button class="action" onclick="loadSite()">Go</button></div><div class="browser-page" id="browserPage"><div style="font-size:70px">🧭</div><h1>Browser</h1><p>A tiny browser mockup for your GitHub Pages desktop.</p><div class="searchbox"><input id="search" placeholder="Search the web"><button onclick="fakeSearch()">Search</button></div></div></div>`},
notes:{title:"Notes",html:`<div class="notes"><aside class="note-list"><button onclick="showNote(0)">📌 Welcome</button><button onclick="newNote()">＋ New Note</button></aside><div class="editor"><input id="noteTitle" value="${notes[0].title}"><textarea id="noteBody">${notes[0].body}</textarea></div></div>`},
calculator:{title:"Calculator",html:`<div class="calculator"><div class="calcbox"><div class="calc-display" id="calcDisplay">0</div><div class="calc-grid"><button class="gray" onclick="calcClear()">AC</button><button class="gray" onclick="calcSign()">±</button><button class="gray" onclick="calcPercent()">%</button><button class="operator" onclick="calcOp('/')">÷</button><button onclick="calcNum(7)">7</button><button onclick="calcNum(8)">8</button><button onclick="calcNum(9)">9</button><button class="operator" onclick="calcOp('*')">×</button><button onclick="calcNum(4)">4</button><button onclick="calcNum(5)">5</button><button onclick="calcNum(6)">6</button><button class="operator" onclick="calcOp('-')">−</button><button onclick="calcNum(1)">1</button><button onclick="calcNum(2)">2</button><button onclick="calcNum(3)">3</button><button class="operator" onclick="calcOp('+')">+</button><button class="zero" onclick="calcNum(0)">0</button><button onclick="calcNum('.')">.</button><button class="operator" onclick="calcEquals()">=</button></div></div></div>`},
terminal:{title:"Terminal",html:`<div class="terminal"><div class="term-output" id="termOutput">Last login: today on GitHub macOS\\nType "help" for available commands.\\n</div><div class="term-line"><span>guest@macos ~ %</span><input class="term-input" id="termInput" autofocus></div></div>`},
trash:{title:"Trash",html:`<div class="trash"><div class="big">🗑️</div><h2>Trash</h2><p class="empty">Trash is empty.</p></div>`}
};

function openApp(name){
  const existing=[...document.querySelectorAll(".window")].find(w=>w.dataset.app===name);
  if(existing){existing.style.zIndex=++z; existing.classList.add("active"); return;}
  const node=template.content.firstElementChild.cloneNode(true); node.dataset.app=name; node.style.zIndex=++z;
  node.querySelector(".title").textContent=apps[name].title; node.querySelector(".window-body").innerHTML=apps[name].html;
  windows.appendChild(node); makeDraggable(node); node.querySelector(".close").onclick=()=>node.remove();
  node.querySelector(".min").onclick=()=>node.classList.toggle("hidden");
  node.querySelector(".max").onclick=()=>node.classList.toggle("maximized");
  node.addEventListener("mousedown",()=>node.style.zIndex=++z); node.classList.add("active");
  if(name==="terminal") setTimeout(()=>node.querySelector("#termInput")?.focus(),50);
}
document.addEventListener("click",e=>{const b=e.target.closest("[data-open]");if(b)openApp(b.dataset.open)});
function makeDraggable(w){
 let drag=false,ox=0,oy=0;
 const bar=w.querySelector(".titlebar");
 bar.addEventListener("mousedown",e=>{if(e.target.tagName==="BUTTON"||w.classList.contains("maximized"))return;drag=true;ox=e.clientX-w.offsetLeft;oy=e.clientY-w.offsetTop;w.style.zIndex=++z});
 document.addEventListener("mousemove",e=>{if(!drag)return;w.style.left=Math.max(0,e.clientX-ox)+"px";w.style.top=Math.max(31,e.clientY-oy)+"px"});
 document.addEventListener("mouseup",()=>drag=false);
}
function updateClock(){document.getElementById("clock").textContent=new Intl.DateTimeFormat([], {weekday:"short",hour:"numeric",minute:"2-digit"}).format(new Date())}
setInterval(updateClock,1000);updateClock();

let calc={v:"0",a:null,op:null,reset:false};
function d(){return document.getElementById("calcDisplay")}
function calcNum(n){if(calc.reset){calc.v="0";calc.reset=false} if(n==="."&&calc.v.includes("."))return; calc.v=calc.v==="0"&&n!=="."?String(n):calc.v+n;d().textContent=calc.v}
function calcClear(){calc={v:"0",a:null,op:null,reset:false};d().textContent="0"}
function calcSign(){calc.v=String(-Number(calc.v));d().textContent=calc.v}
function calcPercent(){calc.v=String(Number(calc.v)/100);d().textContent=calc.v}
function calcOp(op){calc.a=Number(calc.v);calc.op=op;calc.reset=true}
function calcEquals(){if(calc.op===null)return;let b=Number(calc.v),r=0; if(calc.op==="+")r=calc.a+b;if(calc.op==="-")r=calc.a-b;if(calc.op==="*")r=calc.a*b;if(calc.op==="/")r=b===0?"Error":calc.a/b;calc.v=String(r);calc.op=null;calc.reset=true;d().textContent=calc.v}

function showNote(i){document.getElementById("noteTitle").value=notes[i].title;document.getElementById("noteBody").value=notes[i].body}
function newNote(){notes.push({title:"New Note",body:""});showNote(notes.length-1)}
function fakeSearch(){const q=document.getElementById("search").value.trim();document.getElementById("browserPage").innerHTML=`<div style="font-size:60px">🔎</div><h2>Search</h2><p>You searched for <b>${escapeHtml(q||"nothing")}</b>.</p><button class="action" onclick="location.reload()">Back to Browser</button>`}
function loadSite(){document.getElementById("browserPage").innerHTML=`<div style="font-size:60px">🌐</div><h2>Website Preview</h2><p>This demo browser does not fetch external websites.</p>`}
function browserBack(){location.reload()} function browserForward(){}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

document.addEventListener("keydown",e=>{
 const input=document.activeElement;
 if(input?.id==="termInput"&&e.key==="Enter"){
   const cmd=input.value.trim(), out=document.getElementById("termOutput");
   if(cmd==="help")out.textContent+="help  clear  date  about\n";
   else if(cmd==="clear")out.textContent="";
   else if(cmd==="date")out.textContent+=new Date().toString()+"\n";
   else if(cmd==="about")out.textContent+="GitHub macOS — a front-end desktop demo.\n";
   else if(cmd)out.textContent+=`command not found: ${cmd}\n`;
   input.value="";
 }
});
